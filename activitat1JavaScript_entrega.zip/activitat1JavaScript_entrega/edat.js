
var edad = prompt("Quina edad tens?:");

if (edad < 18) {
  alert("accés prohibit");
}
else{
    alert("accés permés")
}
