document.write(new Date)
