Pais=[]
Continent=[]
Llengua=[]
Moneda=[]
for (i=0; i<3; i++)
{var Pais=prompt('Escriu un país: ')
var Continent=prompt('Escriu el continent al que pertany: ')
var Llengua=prompt('Escriu seva llengua: ')
var Moneda=prompt('I quina moneda tenen?: ')
document.write(`<ul><li>${Pais}<ul><li>${Continent}</li><li>${Llengua}</li><li>${Moneda}</li></ul></ul>`)};
