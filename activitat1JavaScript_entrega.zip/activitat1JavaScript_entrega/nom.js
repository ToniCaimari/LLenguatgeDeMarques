var nom = prompt("Por favor, introduce tu nombre:");
alert("confirmat"); 

var mensaje;
var opcion = confirm("Aceptar o Cancelar");
if (opcion == true) {
    alert(mensaje = "nom enregistrat");
} else {
	 alert(mensaje = "Nom no enregistrat");
}
